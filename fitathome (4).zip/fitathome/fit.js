let allRecord= [60, 70, 60, 65, 50];
let dailyRecord = {
    '05/31/2020': [0, 0, 0, 0, 0],
    '06/01/2020': [10, 0, 10, 20, 10],
    '06/02/2020': [0, 30, 15, 15, 0],
    '06/03/2020': [30, 20, 0, 0, 20],
    '06/04/2020': [20, 20, 15, 0, 0],
    '06/05/2020': [0, 0, 20, 30, 20]
};
if(!localStorage.getItem('dailyRecord')){
  localStorage.setItem("dailyRecord", JSON.stringify(dailyRecord));
}
let dailyO = localStorage.getItem("dailyRecord");
dailyO = JSON.parse(dailyO);
let now = new Date().getTime();   
now = format(now, 'MM/dd/yyyy');
now = new Date(now).getTime();
let lastKey = Object.keys(dailyO)[Object.keys(dailyO).length - 1]
let last = new Date(lastKey).getTime();
let days_ = (now-last)/(1000 * 60 * 60 * 24)
for (i = 1; i < days_+1; i++) {
  var newD = last + (1000 * 60 * 60 * 24)*i;
  newD = format(newD, 'MM/dd/yyyy');
  dailyO[newD]	= [0, 0, 0, 0, 0]
}
localStorage.setItem("dailyRecord", JSON.stringify(dailyO));

let lastD = "15 min BOOTY BURN WORKOUT (No Equipment), \
<br /><br />15 min BOOTY BUILD & TONE At Home Workout, \
<br /><br />10 min LOWER ABS Workout LOSE LOWER BELLY FAT, \
<br /><br />10 min STANDING ABS Workout (No Equipment), \
<br /><br />20 min MORNING YOGA (Full Body FlowStretch for Beginners)"
if(!localStorage.getItem('lastD')){
	localStorage.setItem("lastD", JSON.stringify(lastD));
}
if(!localStorage.getItem('allRecord')){
	localStorage.setItem("allRecord", JSON.stringify(allRecord));
}
let target = '2020-06-30'
let days = 21
if(!localStorage.getItem('targetDate')){
	localStorage.setItem("targetDate", JSON.stringify(target));
}
if(!localStorage.getItem('days')){
	localStorage.setItem("days", JSON.stringify(days));
}
window.addEventListener('DOMContentLoaded', function linechart(){
  let date = localStorage.getItem("targetDate");
  date_ = JSON.parse(date);
  document.getElementById('targetDate').innerHTML = date_;
})
window.addEventListener('DOMContentLoaded', function linechart(){
  let days = localStorage.getItem("days");
  days = JSON.parse(days);
  document.getElementById('days').innerHTML = days;
})
let dict = {0: 'Full Body', 1: 'Upper Body', 2: 'Abs', 3: 'Lower Body', 4: 'Stretch'}
function format(time, format) {
  var t = new Date(time);
  var tf = function (i) { return (i < 10 ? '0' : '') + i };
  return format.replace(/yyyy|MM|dd|HH|mm|ss/g, function (a) {
      switch (a) {
          case 'yyyy':
              return tf(t.getFullYear());
              break;
          case 'MM':
              return tf(t.getMonth() + 1);
              break;
          case 'mm':
              return tf(t.getMinutes());
              break;
          case 'dd':
              return tf(t.getDate());
              break;
          case 'HH':
              return tf(t.getHours());
              break;
          case 'ss':
              return tf(t.getSeconds());
              break;
      }
  })
}
function plot(x) {
  let part = dict[x];
	let values= [];
	let dates = [];
  
  let dailyO = localStorage.getItem("dailyRecord");
  dailyO = JSON.parse(dailyO);
  for(var key in dailyO) {
      var value = dailyO[key];
      values.push(value[x]);
      dates.push(key);
    }
	Highcharts.chart('lineChart', {
		chart: {
      reflow: true,
      type: 'area'
    },
    colors: [
			'#5D9CEC'
    ],
		credits: {enabled: false},  
		exporting: {enabled: false},
		xAxis: {
      title: {
        text: 'Dates',
        style: {
          color: '#555',
          fontSize:'15px'
        }
      },
			categories: dates,
			type: 'datetime',
		},
		yAxis: {
      title: {
        text: 'Minutes',
        style: {
          color: '#555',
          fontSize:'15px'
        }
      }
		},
		title: {
			text: 'Your Training Sessions on ' + part,
			style: {
			  color: '#555',
			  fontSize: '25px'
			}
		},
		plotOptions: {
			series: {
				animation: {
					duration: 2000
				}
			}
		},		
		tooltip: {
			formatter: function() {
				var price = this.y
				return price + ' min';
			}
		},
		legend:{ enabled:false },
		series: [{
			data: values
		}]
	})
};
window.addEventListener('DOMContentLoaded', function linechart(){
  let values = []
  let dates = [];
  
  let dailyO = localStorage.getItem("dailyRecord");
  dailyO = JSON.parse(dailyO);
  for(var key in dailyO) {
      var value = dailyO[key];
      dates.push(key);
      var sum = value[0] + value[1] + value[2] + value[3] + value[4];
      values.push(sum);
  }
      Highcharts.chart('lineChart', {
        chart: {
          type: 'area'
        },
        credits: {enabled: false},  
        exporting: {enabled: false},
        xAxis: {
          title: {
            text: 'Dates',
            style: {
              color: '#555',
              fontSize:'15px'
            }
          },
          crosshair: {
            width: 1,
            color: 'gray'
          },
          // tickInterval: parseInt(1054*100/window.innerWidth),
          categories: dates,
          type: 'datetime',
        },
        yAxis: {
          crosshair: {
            width: 1,
            color: 'gray',
          },
          title: {
            text: 'Minutes',
            style: {
              color: '#555',
              fontSize:'15px'
            }
          }
        },
        title: {
          text: 'Your Training Sessions',
          style: {
            color: '#555',
            fontSize: '25px'
          }
        },
        plotOptions: {
          series: {
            animation: {
              duration: 2000
            }
          }
        },		
        tooltip: {
          formatter: function() {
            var price = this.y
            return price + ' min';
          }
        },
        legend:{ enabled:false },
        series: [{
          data: values
        }]
      })
});
window.addEventListener('DOMContentLoaded', function updateDashboard(){
	let dashboard = localStorage.getItem("allRecord");
	dashboard = JSON.parse(dashboard);
	fb = document.getElementById('fb')
	fb.innerHTML=dashboard[0];
	ub = document.getElementById('ub')
	ub.innerHTML=dashboard[1];
	abs = document.getElementById('abs')
  abs.innerHTML=dashboard[2];
  lb = document.getElementById('lb')
  lb.innerHTML=dashboard[3];
  st = document.getElementById('stretch')
  st.innerHTML=dashboard[4];
  tt = document.getElementById('total')
	tt.innerHTML=dashboard[0] +dashboard[1] +dashboard[2] +dashboard[3]+dashboard[4];
});


window.addEventListener('DOMContentLoaded', function lastT(){
  let dailyRecord = localStorage.getItem("dailyRecord");
  dailyRecord = JSON.parse(dailyRecord);
  let dashboard;
  for (i = 1; i < Object.keys(dailyRecord).length+1; i++) {
    key = Object.keys(dailyRecord)[Object.keys(dailyRecord).length - i]
    dashboard = dailyRecord[key]
    let sum = dashboard[0] + dashboard[1] + dashboard[2] + dashboard[3] + dashboard[4];
    if (sum > 0){      
      break;
    }    
  }
  let fb = {
		values: dashboard[0],
		text: "Full Body"
	}
	let ub = {
		values: dashboard[1],
		text: "Upper Body"
  }
  let ab = {
		values: dashboard[2],
		text: "Abs"
	}
	let lb = {
		values: dashboard[3],
		text: "Lower Body"
  }
  let st = {
		values: dashboard[4],
		text: "Stretch"
	}
	
	Highcharts.setOptions({
    chart: {
      style:{
        fontFamily:'Arial, Helvetica, sans-serif', 
        fontSize: '2em',
        color:'#f00'
      }
    }
  });
   Highcharts.chart('lastT', {
        chart: {
            type: 'pie'
        },
        title: {
          text: 'Last Training',
          style: {
            color: '#555',
            fontSize: '25px'
          }
        },
        colors: ['#E6B0AA', '#D2B4DE', '#AED6F1', '#A9DFBF', '#F5CBA7'],
        exporting: {
              enabled: false
        },
        legend: {
            layout: 'horizontal',
            align: 'center',
            verticalAlign: 'bottom',
            borderWidth: 0,
            backgroundColor: '#FFFFFF'
        }, 
        credits: {
            enabled: false
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.1
            },
        series: {
            groupPadding: .15
        },
        pie: {
          innerSize: 80,
          showInLegend: true,
          dataLabels: {
              verticalAlign: 'top',
              enabled: true,
              color: '#FFFFFF',
              connectorWidth: 1,
              distance: -60,
              connectorColor: '#000000',
              formatter: function() {
                  return Math.round(this.percentage) + ' %';
              }
          }
        }               
            },
        series: [{
          type: 'pie',
          data: [
              ['Full Body',   parseFloat(fb['values'])],
              ['Upper Body',   parseFloat(ub['values'])],
              ['Abs',   parseFloat(ab['values'])],
              ['Lower Body',   parseFloat(lb['values'])],
              ['Stretch',   parseFloat(st['values'])],
          ]
        }]
    });
});
window.addEventListener('DOMContentLoaded', function lastS(){
  let dailyRecord = localStorage.getItem("dailyRecord");
  dailyRecord = JSON.parse(dailyRecord);
  let dashboard;
  let sum;
  for (i = 1; i < Object.keys(dailyRecord).length+1; i++) {
    key = Object.keys(dailyRecord)[Object.keys(dailyRecord).length - i]
    dashboard = dailyRecord[key]
    sum = dashboard[0] + dashboard[1] + dashboard[2] + dashboard[3] + dashboard[4];
    if (sum > 0){      
      break;
    }    
  }
  document.getElementById('lastS').innerHTML = "<br /><br /><br />" + key.toString() + "<br /><br /><br /><br /><br /><br /><br /><br /><br />" + sum.toString().fontsize(20) + "<br /><br /><br /><br /> minutes";
	
});
window.addEventListener('DOMContentLoaded', function lastD(){
  let lastD = localStorage.getItem("lastD");
  lastD = JSON.parse(lastD);
  str = "<br /><br /><br /><br />You Did Workouts <br /><br /><br />"
  document.getElementById('lastD').innerHTML = str.toString().fontsize(5) + lastD;
});
function updateD(){	
  let date_ = document.getElementById('date').value;
  date = new Date(date_).getTime();
  var now = new Date().getTime();    
  var distance = date - now;   
  var days = 2+Math.floor(distance / (1000 * 60 * 60 * 24));        
  if (days < 0) {
    document.getElementById('days').innerHTML = "EXPIRED";
  }
  else {
    document.getElementById('days').innerHTML = days;
    document.getElementById('targetDate').innerHTML = date_;
    localStorage.setItem("targetDate", JSON.stringify(date_));
  }  
}
window.addEventListener('DOMContentLoaded', function piechart(){
  let date = localStorage.getItem("targetDate");
  date_ = JSON.parse(date);
  document.getElementById('targetDate').innerHTML = date_;
  date = new Date(date_).getTime();
  var now = new Date().getTime();    
  var distance = date - now;   
  var days = 2+Math.floor(distance / (1000 * 60 * 60 * 24));
  document.getElementById('days').innerHTML = days;
})
window.addEventListener("resize", function () {
  location.reload();
});


window.onload = function () {
  var ImageMap = function (map) {
          var n,
              areas = map.getElementsByTagName('area'),
              len = areas.length,
              coords = [],
              previousWidth = 960;
          for (n = 0; n < len; n++) {
              coords[n] = areas[n].coords.split(',');
          }
          this.resize = function () {
              var n, m, clen,
              current = document.body.clientWidth
              current = 0.9*current/2;
                  x = current / previousWidth;
              for (n = 0; n < len; n++) {
                  clen = coords[n].length;
                  for (m = 0; m < clen; m++) {
                      coords[n][m] *= x;
                  }
                  areas[n].coords = coords[n].join(',');
              }
              previousWidth = document.body.clientWidth;
              return true;
          };
          window.onresize = this.resize;
      },
      imageMap = new ImageMap(document.getElementById('map_ID'));
  imageMap.resize();
  // location.reload();
}



function format(time, format) {
    var t = new Date(time);
    var tf = function (i) { return (i < 10 ? '0' : '') + i };
    return format.replace(/yyyy|MM|dd|HH|mm|ss/g, function (a) {
        switch (a) {
            case 'yyyy':
                return tf(t.getFullYear());
                break;
            case 'MM':
                return tf(t.getMonth() + 1);
                break;
            case 'mm':
                return tf(t.getMinutes());
                break;
            case 'dd':
                return tf(t.getDate());
                break;
            case 'HH':
                return tf(t.getHours());
                break;
            case 'ss':
                return tf(t.getSeconds());
                break;
        }
    })
  }
function add_workout(name, min, type) {
    let dict = {'fb': 0, 'ub': 1, 'ab': 2, 'lb': 3, 'st': 4}
    let index = dict[type]
    let today = new Date().getTime();   
    today = format(today, 'MM/dd/yyyy');
    console.log(today);

    let lastD = localStorage.getItem("lastD");
    lastD = JSON.parse(lastD);
    let dailyRecord = localStorage.getItem("dailyRecord");
    dailyRecord = JSON.parse(dailyRecord);
    let value = dailyRecord[today]
    var sum = value[0] + value[1] + value[2] + value[3] + value[4];
    if (sum > 0) {        
        lastD = lastD + '<br /><br />' + name;
    }
    else {
        lastD = name;
    }    
    localStorage.setItem("lastD", JSON.stringify(lastD));

    dailyRecord[today][index] += min;
    localStorage.setItem("dailyRecord", JSON.stringify(dailyRecord));   
    console.log(localStorage);

    let allRecord = localStorage.getItem("allRecord");
    allRecord = JSON.parse(allRecord);
    allRecord[index] += min;
    localStorage.setItem("allRecord", JSON.stringify(allRecord));
    location.reload();
}
let dict = {0: 'Full Body', 1: 'Upper Body', 2: 'Abs', 3: 'Lower Body', 4: 'Stretch'}
window.addEventListener('DOMContentLoaded', function linechart(){
    let part = dict[x];
      let values= [];
      let dates = [];
    
    let dailyO = localStorage.getItem("dailyRecord");
    dailyO = JSON.parse(dailyO);
    for(var key in dailyO) {
        var value = dailyO[key];
        values.push(value[x]);
        dates.push(key);
      }
      Highcharts.chart('lineChart', {
          chart: {
        reflow: true,
        type: 'area'
      },
      colors: [
              '#5D9CEC'
      ],
          credits: {enabled: false},  
          exporting: {enabled: false},
          xAxis: {
        title: {
          text: 'Dates',
          style: {
            color: '#555',
            fontSize:'15px'
          }
        },
              categories: dates,
              type: 'datetime',
          },
          yAxis: {
        title: {
          text: 'Minutes',
          style: {
            color: '#555',
            fontSize:'15px'
          }
        }
          },
          title: {
              text: 'Your Training Sessions on ' + part,
              style: {
                color: '#555',
                fontSize: '25px'
              }
          },
          plotOptions: {
              series: {
                  animation: {
                      duration: 2000
                  }
              }
          },		
          tooltip: {
              formatter: function() {
                  var price = this.y
                  return price + ' min';
              }
          },
          legend:{ enabled:false },
          series: [{
              data: values
          }]
      })
  });